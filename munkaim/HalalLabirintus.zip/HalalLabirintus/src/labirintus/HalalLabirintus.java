package labirintus;

import java.awt.HeadlessException;
import java.util.Random;
import javax.swing.JOptionPane;

public class HalalLabirintus {
    public static int Ugyesseg, Eletero, Szerencse, gomb, optTipus, msgt, Arany;
    public static String szoveg, cím;
    public static Object[] gombopciok = {"ballra","Jobbra"};

    public static void main(String[] args) {
        Labirintus();
    }

    private static void Labirintus() {
        dobasok();
        bevezetes();
        jatekmenet();
    }

    private static void dobasok() {
        Random rnd = new Random();
        
        
        Ugyesseg = 6 + rnd.nextInt(1, 7);
        Eletero = 12 + rnd.nextInt(2, 13);
        Szerencse = 6 + rnd.nextInt(1, 7);   
        Arany = 0;
    }
    private static void bevezetes(){
        szoveg = "Egy versenyre nevezel, aminek a lényege, hogy át kell "
                + "kelni a halállabirintuson. A labirintusban tárgyakat "
                + "találhatsz és szörnyekkel kell harcoljál.";
        optTipus = JOptionPane.INFORMATION_MESSAGE;
        cím = "Kezdés";
        JOptionPane.showMessageDialog(null, szoveg, cím, optTipus);
        KiIr();
    }

    private static void jatekmenet() {
        szoveg = "Miután öt percet haladtál lassan az alagútban, "
                + "egy kőasztalhoz érsz, amely a bal oldali fal mellett áll. "
                + "\nHat doboz van rajta, egyikükre a te neved festették. "
                + "Ha ki akarod nyitni a dobozt, menj ballra. "
                + "Ha inkább tovább haladsz észak felé, menj jobbra.";
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.YES_NO_OPTION;
        cím = "1. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        if (gomb == JOptionPane.YES_OPTION){
            kettohetven_Oldal();
        }else{
            hatvanhat_Oldal();
        }
        
    }
    private static void Otvenhat_Oldal() {
        szoveg = "Látod, hogy az akadály egy széles, barna, sziklaszerű tárgy. "
                + "\nMegérinted, és meglepve tapasztalod, hogy lágy, szivacsszerű. "
                + "Ha át szeretnél mászni rajta, menj ballra. "
                + "Ha ketté akarod vágni a kardoddal, menj jobbra.";
                
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.YES_NO_OPTION;
        cím = "56. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        if (gomb == JOptionPane.YES_OPTION){
            HaromHetvenHarom_Oldal();
        }else{
            KettoTizenOt_Oldal();
        }
    }

    private static void hatvanhat_Oldal() {
        szoveg = "Néhány perc gyaloglás után egy elágazáshoz érsz "
                + "az alagútban. Egy, a falra festett fehér nyíl nyugatfelé "
                + "mutat. A földön nedves lábnyomok jelzik, "
                + "\nmerre haladtak az előtted járók. Nehéz biztosan megmondani, "
                + "de úgy tűnik, hogy három közülük a nyíl irányába halad, "
                + "míg egyikük úgy döntött, hogy keletnek megy. "
                + "\nHa nyugat felé kívánsz menni, menj ballra "
                + "Ha keletnek, jobbra.";
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.YES_NO_OPTION;
        cím = "66. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        if (gomb == JOptionPane.YES_OPTION){
            KettoKilencvenHarom_Oldal();
        }else{
            Otvenhat_Oldal();
        }
    }
    // harang jobb ball jobb
    private static void EgyHarmincHet_Oldal() {
        szoveg = "Ahogy végigmész az alagúton, csodálkozva látod, hogy egy jókora "
                + "vasharang csüng alá a boltozatról.";
        msgt = JOptionPane.INFORMATION_MESSAGE;
        cím = "137. Oldal";
        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
        KiIr();
    }
    // Gomba spóra jobb jobb
    private static void KettoTizenOt_Oldal() {
        szoveg = "Kardod könnyedén áthatol a spóragolyó vékonykülső burkán. "
                + "\nSűrű barna spórafelhő csap ki a golyóból, és körülvesz. "
                + "Némelyik spóra a bőrödhöz tapad, és rettenetes viszketést okoz."
                + " \nNagy daganatok nőnek az arcodon és karodon, és a bőröd mintha égne."
                + " 2 ÉLETERŐ pontot veszítesz. \nVadul vakarózva átléped a leeresztett golyót,"
                + " és keletnek veszed az utad.";
        msgt = JOptionPane.INFORMATION_MESSAGE;
        cím = "215. Oldal";
        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
        Eletero = Eletero - 2 ;
        KiIr();
    }
    
    private static void kettohetven_Oldal() {
        Object[] gombopciok = {"előre"};
        szoveg = "A doboz teteje könnyedén nyílik. Benne két aranypénzt találsz, "
                + "és egy üzenetet, amely egy kis pergamenen neked szól. "
                + "Előbb zsebre vágod az aranyakat, aztán elolvasod az üzenetet: "
                + "\n- „Jól tetted. Legalább volt annyi eszed, hogy megállj "
                + "és elfogadd az ajándékot. Most azt tanácsolom neked, "
                + "hogy keress és használj különféle tárgyakat, ha sikerrel "
                + "akarsz áthaladni Halállabirintusomon.” \nAz aláírás Szukumvit. "
                + "Megjegyzed a tanácsot, apró darabokra téped a pergament, "
                + "és tovább mész észak felé.";
                
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.OK_OPTION;
        cím = "270. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        Arany = Arany + 2;
        if (gomb == JOptionPane.OK_OPTION){
            hatvanhat_Oldal();
        }else{
            hatvanhat_Oldal();
        }
    }

    private static void KettoKilencvenHarom_Oldal() {
        szoveg = "A három pár nedves lábnyomot követve az alagút nyugati "
                + "elágazásában hamarosan egy újabb el-ágazáshoz érsz. "
                + "\nHa továbbmész nyugat felé a lábnyomokat követve, menj ballra. "
                + "Ha inkább észak felé mész a harmadik pár lábnyom után, "
                + "menj jobbra";
                
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.YES_NO_OPTION;
        cím = "293. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        if (gomb == JOptionPane.YES_OPTION){
            EgyHarmincHet_Oldal();
        }else{
            HaromNyolcvanHet_Oldal();
        }
    }
    
    private static void HaromHetvenHarom_Oldal() {
        szoveg = "Fölmászol a lágy sziklára, attól tartasz, "
                + "hogy bár-melyik pillanatban elnyelhet. \nNehéz átvergődni rajta,"
                + " mert puha anyagában alig tudod a lábadat emelni, de végül "
                + "átvergődsz rajta. \nMegkönnyebbülten érsz újra szilárd talajra, "
                + "és fordulsz kelet felé.";
        msgt = JOptionPane.INFORMATION_MESSAGE;
        cím = "373. Oldal";
        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
        KiIr();
    }

    private static void HaromNyolcvanHet_Oldal() {
        Object[] gombopciok = {"Csata"};
        szoveg = "Hallod, hogy elölről súlyos lépések közelednek. "
                + "Egy széles, állatbőrökbe öltözött, kőbaltás, primitív lény lép elő. "
                + "\nAhogy meglát, morog, a földre köp, majd a kőbaltát felemelve "
                + "közeledik, és mindennek kinéz, csak barátságosnak nem. "
                + "\nElőhúzod kardodat, és felkészülsz, hogy megküzdj a "
                + "Barlangi Emberrel.";
        msgt = JOptionPane.PLAIN_MESSAGE;
        optTipus = JOptionPane.OK_OPTION;
        cím = "387. Oldal";
        gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                null, gombopciok, null);
        if (gomb == JOptionPane.OK_OPTION){
            Harc();
        }else{
            Harc();
        }
    }
    private static void KiIr(){
        cím = "Játékos Statisztika";
        msgt = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, "Életerő: "+Eletero+"\nÜgyesség: "
                +Ugyesseg+"\nSzerencse: "+Szerencse+"\nArany: "+Arany, cím, msgt);
    }
    //ball, ball jobb
    private static void Harc() {
        Random rnd = new Random();
        int E_Tamadoero;
        int E_Eletero = 7;
        int szamlalo = 0;
        while (E_Eletero > 0 && Eletero > 0){
            szoveg = "Életerőd: "+Eletero+"\nSzerencse: "+Szerencse+"\nBarlanglakó Statisztikák: "+"\nÉletereje: "+E_Eletero;
            msgt = JOptionPane.INFORMATION_MESSAGE;
            JOptionPane.showMessageDialog(null, szoveg, szamlalo+". Kör", msgt);
            int Sebzes = 2;
            E_Tamadoero = 7 + rnd.nextInt(2,13);
            Ugyesseg = Ugyesseg + rnd.nextInt(2,13);
            if (Ugyesseg > E_Tamadoero){
                Object[] gombopciok = {"Szerencsés Támadás","Nem élek a lehetőséggel"};
                szoveg = "A te támadásod nagyobb volt mint a barlanglakóé, ezért"
                        + "sebzést mérhetsz az ellenfélre"
                        + "\nVan lehetőséged szerencsésen támadni, de vigyázz! "
                        + "Lehetsz balszerencsés is.";
                msgt = JOptionPane.PLAIN_MESSAGE;
                optTipus = JOptionPane.YES_NO_OPTION;
                cím = "Támadás";
                gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                        null, gombopciok, null);
                if (gomb == JOptionPane.YES_OPTION){
                    int esely = rnd.nextInt(2,13);
                    if (Szerencse > esely){
                        Sebzes += 2;
                        szoveg = "Szerencsés voltál!";
                        msgt = JOptionPane.INFORMATION_MESSAGE;
                        cím = "Szerencse!";
                        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
                    }else{
                        Sebzes-=1;
                        szoveg = "Nem voltál szerencsés!";
                        msgt = JOptionPane.INFORMATION_MESSAGE;
                        cím = "Szerencse!";
                        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
                    }
                    Szerencse -= 1;
                    E_Eletero = E_Eletero - Sebzes;
                }else{
                    E_Eletero = E_Eletero - Sebzes;
                }
            }else if (Ugyesseg < E_Tamadoero){
                Object[] gombopciok = {"Szerencsés felhasználás","Nem élek a lehetőséggel"};
                szoveg = "A barlanglakó támadása erősebb volt mint a te támadásod"
                        + "\nVan lehetőséged csökkenteni a sebzést, de vigyázz! "
                        + "Lehetsz balszerencsés is.";
                msgt = JOptionPane.PLAIN_MESSAGE;
                optTipus = JOptionPane.YES_NO_OPTION;
                cím = "Támadás";
                gomb = JOptionPane.showOptionDialog(null, szoveg, cím, optTipus, msgt, 
                        null, gombopciok, null);
                if (gomb == JOptionPane.YES_OPTION){
                    int esely = rnd.nextInt(2,13);
                    if (Szerencse > esely){
                        szoveg = "Szerencsés voltál!";
                        msgt = JOptionPane.INFORMATION_MESSAGE;
                        cím = "Szerencse!";
                        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
                        Sebzes -=1;
                    }else{
                        szoveg = "Nem voltál szerencsés!";
                        msgt = JOptionPane.INFORMATION_MESSAGE;
                        cím = "Szerencse!";
                        JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
                        Sebzes+=1;
                    }
                    Szerencse -= 1;
                   Eletero = Eletero - Sebzes;
                }else{
                    Eletero = Eletero - Sebzes;
                }
            }else{
                szoveg = "Támadó erőtök megegyezik, ezért új kör kezdődik!";
                msgt = JOptionPane.INFORMATION_MESSAGE;
                cím = "Támadás";
                JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
            }
            szamlalo++;
        }
        if (Eletero < E_Eletero){
            szoveg = "Meghaltál!";
            msgt = JOptionPane.INFORMATION_MESSAGE;
            cím = "Játék vége!";
            JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
        }else{
            szoveg = "Megnyerted a csatát!";
            msgt = JOptionPane.INFORMATION_MESSAGE;
            cím = "Játék vége!";
            JOptionPane.showMessageDialog(null, szoveg, cím, msgt);
            KiIr();
        }
        
        
    }
    
    
}
