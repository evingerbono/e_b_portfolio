# kepes_grid
Egy két dolgot nemtudtam megcsinálni azt majd a Tanárnőtől szeretném megkérdezni órán.
