package evingerbono_kviz;

import java.awt.HeadlessException;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class EvingerBono_Kviz {

    public static void main(String[] args) {

        jatek();

    }

    private static void jatek() throws HeadlessException, NumberFormatException {
        jatekmenet();
        ujrakezdes();
    }

    private static void ujrakezdes() throws NumberFormatException, HeadlessException {
        boolean folytatas = false;
        
        while (!folytatas) {
            String cim = "Újra kezdés";
            int msgTipus = 0;
            Icon kep = new ImageIcon("src/kep/kerdes.png");
            String kerdes = "Újra akarod kezdeni a játékot?";
            int optTipus = JOptionPane.YES_NO_OPTION;
            kep = new ImageIcon("src/kep/kerdes.png");
            int gomb = JOptionPane.showConfirmDialog(null, kerdes, cim, optTipus, msgTipus, kep);

            if (gomb == JOptionPane.YES_OPTION) {
                jatekmenet();
            } else {
                System.exit(0);
                folytatas=true;
            }
        }
    }

    private static void jatekmenet() throws NumberFormatException, HeadlessException {
        nev_bekeres();
        kerdesek();
    }

    private static void kerdesek() throws HeadlessException, NumberFormatException {
        int jo_valasz = 0;
        String kerdes = "Melyik programozó nyelven iratunk ki így: Console.WriteLine('Sziasztok')";
        String cim = "Felelet választós";
        int msgTipus = JOptionPane.QUESTION_MESSAGE;
        Icon kep = new ImageIcon("src/kep/kerdes.png");
        Object[] valaszok = {"Python", "Java", "C#", "Sql"};
        Object kijelolve = "Sql";
        Object valasz = JOptionPane.showInputDialog(null, kerdes, cim, msgTipus, kep, valaszok, kijelolve);
        valasz = valasz == null ? "nincs" : valasz;
        if (valasz == "C#") {
            jo_valasz += 1;
        }
        String info = "A helyes válasz: C# ";
        cim = "Jó válasz";
        msgTipus = JOptionPane.INFORMATION_MESSAGE;
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);

        kerdes = "Mennyi Math.pow(13,2)";
        int szamolos_kerdes = Integer.parseInt(JOptionPane.showInputDialog(null, kerdes));
        if (szamolos_kerdes == 169) {
            jo_valasz += 1;
        }
        info = "A helyes válasz: 169 ";
        cim = "Jó válasz";
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);

        kerdes = "Hogyan kérünk be Java nyelven valós számot?";
        cim = "Felelet választós2";
        Object[] valaszok2 = {"int", "boolean", "String", "double", "char"};
        Object kijelolve2 = "int";
        Object valasz2 = JOptionPane.showInputDialog(null, kerdes, cim, msgTipus, kep, valaszok2, kijelolve2);
        valasz2 = valasz2 == null ? "nincs" : valasz2;
        if (valasz2 == "double") {
            jo_valasz += 1;
        }
        info = "A helyes válasz: double ";
        cim = "Jó válasz";
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);

        kerdes = "Mennyi Math.sqrt(225)";
        szamolos_kerdes = Integer.parseInt(JOptionPane.showInputDialog(null, kerdes));
        if (szamolos_kerdes == 15) {
            jo_valasz += 1;
        }
        info = "A helyes válasz: 15 ";
        cim = "Jó válasz";
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);
        
        kerdes = "Melyik program nyelven kell be importálni a Rondomot?";
        cim = "Felelet választós3";
        Object[] valaszok3 = {"Java", "Python", "Mindkettő"};
        Object kijelolve3 = "Java";
        Object valasz3 = JOptionPane.showInputDialog(null, kerdes, cim, msgTipus, kep, valaszok3, kijelolve3);
        valasz3 = valasz3 == null ? "nincs" : valasz3;
        if (valasz3 == "Mindkettő") {
            jo_valasz += 1;
        }
        info = "A helyes válasz: Mindkettő ";
        cim = "Jó válasz";
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);

        cim = "Eredmény";
        info = "Összesen ennyi jó választ adtál: " + jo_valasz;
        JOptionPane.showMessageDialog(null, info, cim, msgTipus);
    }

    private static void nev_bekeres() throws HeadlessException {
        boolean jo_nev = false;
        while (!jo_nev) {
            String nev = JOptionPane.showInputDialog("név: ");
            if (nev.length() < 3) {
                nev = JOptionPane.showInputDialog("név: ");
            } else {
                jo_nev = true;
            }
        }
    }

}
